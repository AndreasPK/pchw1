./eflf < $1.efl > $1.f90
