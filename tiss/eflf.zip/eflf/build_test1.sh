./eflf < test1.efl > test1.f90
gfortran -o test1 test1.f90
